Puspose: This script is used to generate the Stats file of GN components and push to EMS.

Input: stats.cfg file in which EMS Ip address , username , password and path is defined for a GN.

How to run: 
    Add required parameters in stats.cfg file and run below command:
    "sudo python modStats.py"



