Puspose: This script is used to calcuate the response delay of SNMP message from RCM to BUCAMP.

Input: ip-list.txt(Includes the list of all Ips on RCM(all SAPs and Polarization)

How to run: 
    Add the list of RCM ips in ip-list.txt file and run below command:
    "nohup sudo python runTcpDump.py &"


