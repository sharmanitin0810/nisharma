#-----------------------------------------------------------------------------------------
# PURPOSE: To Retrieve SAP Equipment / Satellite Contact Details of Ground network (GN)
#
# SOURCE CODE FILE: GN_SAT_CONTACT_ANALYSER.py
#
# REVISION HISTORY:
#          DATE:           AUTHOR:         CHANGE:
#          26-08-19        Amit Soni       Initial version
#          30-08-19        Nitin Sharma    Provided Support for retrieving sap_euipment/scheduled/active/failed sat contacts
#          02-09-19        Nitin/Manish    Final Version Incorporated review comments suggested by Amit.
#
# Copyright 2019 Hughes Network Systems Inc
#-----------------------------------------------------------------------------------------
#!/usr/bin/python
# Version 2

###############################################################################
#
#       Prerequisites to run this script:
#       ---------------------------------------
#               - Python 2.7 must be installed
#       Command Line Parameters to this script:
#
#       ---------------------------------------
#               $1 = RMS Ip address of GN.
#
#       Return values of the script:
#       ----------------------------
#               On successful execution, the exit status is 0
#
###############################################################################

##########################################
# --- Imported Basic Needful Modules --- #
##########################################

import time
import os
import paramiko
import readline 
import signal
import errno  
import logging
from datetime import datetime


#####################################
# --- Function to Handle Signal --- #
#####################################

def signal_handler(signal,frame):
	print('\n')
        print("Entering Signal Handler to Handle Recieved Signal")
        print('\n');print (" Successfully exited on User Request !! ")
        exit(0)

################################################
# --- Function to Create Directory for Log --- #
################################################

def create_log_dir():
        dir_log = 'sap_logs'
        try:
           os.mkdir(dir_log)
           print("Logger Directory is Created")

        except OSError as e:
            if e.errno == errno.EEXIST:
                print("Log Directory already Exist - Not Creating Again")

#########################################################
# --- Function to Create Directory for Output Files --- #
#########################################################

def create_dir():

    global logger
    dir_all = 'sap_contact_detail'
    dir_equip= 'sap_contact_detail/sap_equipment'
    dir_sched = 'sap_contact_detail/sap_schedule_contact'
    dir_act = 'sap_contact_detail/sap_active_contact'
    dir_fail = 'sap_contact_detail/sap_failed_contact'

    try:
        os.mkdir(dir_all)
        os.mkdir(dir_equip)
        os.mkdir(dir_sched)
        os.mkdir(dir_act)
        os.mkdir(dir_fail)

        logger.debug("All Sap File Directries are Successfully Created ")

    except OSError as e:
        if e.errno == errno.EEXIST:
                print("All Sap Files Directories already Exist - Not Creating Again")
                print("Error Number : ",e.errno)

###############################################
# --- Function for Getting SAP_EQUIPMENTS --- #
###############################################

def get_sap_equip(rms_ip):
	
	client = paramiko.SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect(rms_ip, username='msat', password='oneweb123',port=22)
	stdin, stdout, stderr = client.exec_command(' shopt -s expand_aliases ; source ~/.bash_aliases ; eval dumpSapEquipment');print('\n')
	fileText=stdout.read()
        logftime=time.strftime("%Y%d%d_%H%M%S")
        print("Sap_Equipment_File is generated : sap_contact_detail/sap_equipment/sap_equip_"+str(logftime)+".txt");print('\n')
	with open("sap_contact_detail/sap_equipment/sap_equip_"+str(logftime)+".txt","w") as writer:
	  logger.info("SAP Equipment are retrived Successfully.")
          writer.write(fileText)
	client.close()

###################################################
# --- Function for Getting SCHEDULED_CONTACTS --- #
###################################################

def get_sch_contact(rms_ip):
 
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(rms_ip, username='msat', password='oneweb123',port=22)
        stdin, stdout, stderr = client.exec_command(' shopt -s expand_aliases ; source ~/.bash_aliases ; eval dumpContactSchedule | sort -k2');print('\n')
        fileText=stdout.read()
        logftime=time.strftime("%Y%d%d_%H%M%S")
        print("Scheduled Contact File is generated : sap_contact_detail/sap_schedule_contact/schedule_contact_"+str(logftime)+".txt");print('\n')
        with open("sap_contact_detail/sap_schedule_contact/schedule_contact_"+str(logftime)+".txt","w") as writer:
	  logger.info("Scheduled Contacts  are retrived Successfully.")
          writer.write(fileText)
        client.close()

################################################
# --- Function for Getting ACTIVE_CONTACTS --- #
################################################

def get_act_contact(rms_ip):
 
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(rms_ip, username='msat', password='oneweb123',port=22)
        stdin, stdout, stderr = client.exec_command(' shopt -s expand_aliases ; source ~/.bash_aliases ; eval dumpActiveContacts | sort -k2');print('\n')
	fileText=stdout.read()
        logftime=time.strftime("%Y%d%d_%H%M%S")
        print("Active Contact File is generated : sap_contact_detail/sap_active_contact/active_contact_"+str(logftime)+".txt");print('\n')
        with open("sap_contact_detail/sap_active_contact/active_contact_"+str(logftime)+".txt","w") as writer:
	  logger.info("Active Contacts  are retrived Successfully.")
          writer.write(fileText)
        client.close()

################################################
# --- Function for Getting FAILED_CONTACTS --- #
################################################

def get_Fail_contact(rms_ip):
 
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(rms_ip, username='msat', password='oneweb123',port=22)
        stdin, stdout, stderr = client.exec_command(' shopt -s expand_aliases ; source ~/.bash_aliases ; eval dumpFailedContacts | sort -k2');print('\n')
	fileText=stdout.read()
        logftime=time.strftime("%Y%d%d_%H%M%S")
        print("Failed Contact File is generated : sap_contact_detail/sap_failed_contact/failed_contact_"+str(logftime)+".txt");print('\n')
        with open("sap_contact_detail/sap_failed_contact/failed_contact_"+str(logftime)+".txt","w") as writer:
	  logger.info("Failed Contacts  are retrived Successfully.")
          writer.write(fileText)
        client.close()

######################################	 
# --- Function for START_UP MENU --- #
######################################

def start_menu():
	
     try:
	global rms_ip	
	print("#####***********************************#####")
	print("####### GN SATELLITE CONTACT ANALYSER #######")
	print("#####***********************************#####");print('\n')

	print("Press 1 ---> To view SAP Equipment ")	
	print("Press 2 ---> To view Scheduled Satellite Contacts ")	
	print("Press 3 ---> To view Active Satellite Contacts ")	
	print("Press 4 ---> To view Failed Satellite Contacts ")	
	print("Press 5 ---> Exit ");print('\n')	
	
	choice = raw_input("Your Choice: ")
	if choice=='1':
                print("Getting SAP Equipment ... Please Wait ..!!")
		time.sleep(1)
                get_sap_equip(rms_ip)
		time.sleep(2);os.system('clear')
		start_menu()

	elif choice=='2':
                print("Getting Scheduled Satellite Contacts ... Please Wait ..!!")
                time.sleep(1)
                get_sch_contact(rms_ip)
		time.sleep(2);os.system('clear')
		start_menu()

	elif choice=='3':
                print("Getting Active Satellite Contacts ... Please Wait ..!!")
                time.sleep(1)
		get_act_contact(rms_ip)
		time.sleep(2);os.system('clear')
		start_menu()

	elif choice=='4':
                print("Getting Failed Satellite Contacts ... Please Wait ..!!")
                time.sleep(1)
                get_Fail_contact(rms_ip)
		time.sleep(2);os.system('clear')
		start_menu()

	elif choice=='5':
                print("Sucessfully Exited ..!!!")
		os.system("exit")
	
	else:
	   print("Invalid Choice .... Please Select a valid Option !!")
	   time.sleep(3)
	   os.system("clear")

	   start_menu()

     except Exception as e:
		 print("Exception Raised is : ",e)
	
######################################################
# --- Execution starts from Here - MAIN_FUNCTION --- #
######################################################

if __name__=="__main__":
		
	signal.signal(signal.SIGINT,signal_handler)
        signal.signal(signal.SIGTSTP,signal_handler)

	os.system("clear")
	
	time.sleep(1)

        create_log_dir()

	#Basic Configuration for Generating Logs 

        logFname = datetime.now().strftime('SAP_DETAILS_%d_%m_%Y:%H_%M.log')
        logging.basicConfig(filename='sap_logs/%s' %(logFname),level=logging.DEBUG,format='%(asctime)s : %(message)s ')
        logger = logging.getLogger()
	

	create_dir();os.system("clear")
 	
	print("##### ***** GN RMS COMPONENT DETAILS ***** #####");print('\n')	
	rms_ip=raw_input("Please Enter the IP Address of RMS : ");os.system('clear')

	start_menu()	

	
