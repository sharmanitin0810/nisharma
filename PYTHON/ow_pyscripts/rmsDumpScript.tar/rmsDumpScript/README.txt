Purpose: This script is used to run RMS dump Commands.

Input: Need to edit the ip address of Active RMS node in the python script according to GN on which you are running it.

How to run: 
    	- Open the File and Enter the Ip address of the Active RMS node in "GW_Data[" <<Site Name>> RMS"] = "10.xx.xx.32" Flag.
	- Run the script using Command - "sudo python rmsDump.py" 


