#-----------------------------------------------------------------------------------------
# PURPOSE: GN componenets Release Upgrade/Downgrade Utility
#
# SOURCE CODE FILE: swActivation.py
#
# REVISION HISTORY:
#          DATE:           AUTHOR:         CHANGE:
#          22-05-19        HSC             Initial version
#          06-09-19        Nitin/Manish    Changes after review comments added.
#
# Copyright 2019 Hughes Network Systems Inc
#-----------------------------------------------------------------------------------------
###############################################################################
#
#       Prerequisites to run this script:
#       ---------------------------------------
#               - Python 2.7 must be installed
#       Command Line Parameters to this script:
#
#       ---------------------------------------
#               $1 = GN ID on which release is to be Installed.
#               $2 = EMS Ip address of GN.
#               $3 = Site Type (SNP/POP)
#               $4 = Component Type (RMS,LXP,AMS,PLS,AXP)
#               $5 = Release Package Name
#               $6 = Rack ID of Component
#               $7 = Blade ID of Component
#               $8 = Activation Time of release
#
#       Return values of the script:
#       ----------------------------
#               On successful execution, the exit status is 0
#
###############################################################################


##########################################
# --- Imported Basic Needful Modules --- #
##########################################

import subprocess
import sys
import pysftp
import time
import os
import readline
import signal
import logging
from datetime import datetime
import errno

#####################################
# --- Function to Handle Signal --- #
#####################################

def signal_handler(signal,frame):
        print('\n')
        logger.debug("Entering Signal Handler to Handle Recieved Signal")
        print('\n');print (" Successfully exited on User Request !! ")
        exit(0)

################################################
# --- Function to Create Directory for Log --- #
################################################

def create_log_dir():
        dir_log = 'sw_logs'
        try:
           os.mkdir(dir_log)
           print("Logger Directory is Created")

        except OSError as e:
            if e.errno == errno.EEXIST:
                print("Log Directory already Exist - Not Creating Again")


################################################
# --- Function to Copy Release file to SW_RELEASE Folder--- #
################################################

def copy_rel(sw_rel):
        try:
	   os.system("sudo cp "+str(sw_rel)+ "\t"   "SW_RELEASE/")
	   logger.debug("Release file moved to SW_RELEASE folder successfully ")

        except Exception  as e:
                print("Exception raised :",e)
            

#######################################################
# --- Function to Create Directory for SW Release --- #
#######################################################

def create_rel_dir():

    global logger
    dir_sw = 'SW_RELEASE'

    try:
        os.mkdir(dir_sw)

        logger.debug("SW release Directries are Successfully Created ")

    except OSError as e:
        if e.errno == errno.EEXIST:
                logger.debug("SW release Directory already Exist - Not Creating Again")
                logger.debug("Error Number : ",e.errno)

######################################
# --- Function for START_UP MENU --- #
######################################

def start_menu():
        global ems_ip,SW_BASE_DIR,progressEveryPercent , progressDict,site,rack,blade,actTime,gn,gnComp,sw
        
	os.system("clear")
	print("""	 	 ------------------------------------------------------
	         ##  GN Components SW release Upgrade/Downgrade Utility ##
	         -------------------------------------------------------""");print('\n')

	gn=input("Enter the GN ID to which Release Installed -> ")
	ems_ip=raw_input("Enter the EMS-IP(Eg.- 10.10.128.21)  -> ")
	site=raw_input("Enter Site type(SNP,POP) -> ")
	gnComp=raw_input("Enter the component type(RMS,LXP,AMS,PLS,AXP) -> ")
	sw=raw_input("Enter the release package(Eg. OW_AXP_8.4.3.tar.gz) to be Installed -> ")
	rack=input("Enter the Rack ID to which Release Installed -> ")
	blade=raw_input("Enter the blade ID to which Release Installed ->")
	actTime=raw_input("Enter the Activation time  to which Release Installed 'UTC'(YYYYMMDDHHMMSS)->")
	print('\n')
	SW_BASE_DIR="SW_RELEASE/"
	copy_rel(sw)
	progressDict={}
	progressEveryPercent=10

	for i in range(0,101):
    		if i%progressEveryPercent==0:
        		progressDict[str(i)]=""

####################################################
# --- Function for printing Release transfer % --- #
####################################################

def printProgressDecimal(x,y):
	global progressEveryPercent
    	if int(100*(int(x)/int(y))) % progressEveryPercent ==0 and progressDict[str(int(100*(int(x)/int(y))))]=="":
		print("{}% ({} Transfered(B)/ {} Total File Size(B))".format(str("%.2f" %(100*(int(x)/int(y)))),x,y))
       		progressDict[str(int(100*(int(x)/int(y))))]="1"

###########################################
# --- Function for FTP release on EMS --- #
###########################################

def sftp():
    try:
        global ems_ip,SW_BASE_DIR,sw

	logger.debug("Entering sftp Function ..")
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        ftp = pysftp.Connection(host=ems_ip, username="msat",password="oneweb123",cnopts=cnopts)
        ftp.chdir("/home/msatftp/GNOC/SWIMAGE")
        #print(ftp.pwd())
        lpath=SW_BASE_DIR+"tmp."+sw
        rename="cp "+SW_BASE_DIR+str(sw)+" "+lpath
        #print(rename)
        os.system(rename)
        #print(lpath)
        time.sleep(2) 
        ftp.put(lpath,callback=lambda x,y: printProgressDecimal(x,y))
        #lambda x,y :  print("{} transfered/ {} to go".format(x,y))
        time.sleep(1)
        logger.debug("\nComponent release copied to EMS")
        time.sleep(5)
        name = "mv /home/msatftp/GNOC/SWIMAGE/""tmp."+str(sw)+" "+"/home/msatftp/GNOC/SWIMAGE/"+str(sw)
        #print(name)
        ftp.execute(name)
        time.sleep(6)
        os.system("rm -rf "+lpath)
        print("\nRelease to be upgraded -> "+sw)

        if site=="POP":
                     curl_pop = """curl -i --insecure -X PUT -H 'Authorization: Bearer 5b87c735ebc11b9382fb9be3a09558486c44ad2f' -H 'Content-Type:application/json' https://10.10.128.21/gnems/EMSAPI/v1/components/sw/activate/componentType/"""+str(gnComp)+"""/pop/"""+str(gn)+"""/rack/"""+str(rack)+"""/chassis/1/blade/"""+str(blade)+""" -d '{"swVersion":"""+'"%s"'%str(sw)+""","activationTime": """+'"%s"'%str(actTime)+""" }'"""
                     print("\n"+curl_pop)
                     logger.debug("\nExecuting Curl Command for POP Upgrade/Downgrade.\n\n")
                     p=subprocess.Popen(curl_pop, stdout=subprocess.PIPE, shell=True)
                     (output, err) = p.communicate()
                     print("\n")
                     print(output) 

        elif site=="SNP":
                     curl_snp = """curl -i --insecure -X PUT -H 'Authorization: Bearer 5b87c735ebc11b9382fb9be3a09558486c44ad2f' -H 'Content-Type:application/json' https://10.10.128.21/gnems/EMSAPI/v1/components/sw/activate/componentType/"""+str(gnComp)+"""/rack/"""+str(rack)+"""/chassis/1/blade/"""+str(blade)+""" -d '{"swVersion":"""+'"%s"'%str(sw)+""","activationTime": """+'"%s"'%str(actTime)+""" }'"""
                     print("\n"+curl_snp)
                     logger.debug("\nExecuting Curl Command for SNP Upgrade/Downgrade.\n\n")
                     p=subprocess.Popen(curl_snp, stdout=subprocess.PIPE, shell=True)
                     (output, err) = p.communicate()
                     print("\n")
                     print(output)

    except Exception as c:
        print(c)
    ftp.close()

if __name__ == "__main__":
	#Basic variables declared
        ems_ip=''	
        SW_BASE_DIR=''
        sw=''
        progressEveryPercent=''
        site=''
        gnComp=''
        blade=''
        rack=''
        actTime=''
        gn=''
	time.sleep(1)

        create_log_dir()

        #Basic Configuration for Generating Logs

        logFname = datetime.now().strftime('GN_COMP_SW_%d_%m_%Y:%H_%M.log')
        logging.basicConfig(filename='sw_logs/%s' %(logFname),level=logging.DEBUG,format='%(asctime)s : %(message)s ')
        logger = logging.getLogger()

	signal.signal(signal.SIGINT,signal_handler)
        signal.signal(signal.SIGTSTP,signal_handler)

        create_rel_dir();os.system("clear")

	start_menu()

	sftp()	
