#-----------------------------------------------------------------------------------------
# PURPOSE: To change desired state of components of Ground network (GN)
#
# SOURCE CODE FILE: GN_COMP_STATE_MODIFYER.py
#
# REVISION HISTORY:
#          DATE:           AUTHOR:         CHANGE:
#          27-09-19        Amit/Manish    Initial version
#          04-10-19        Nitin Sharma    Final version
#
# Copyright 2019 Hughes Network Systems Inc
#-----------------------------------------------------------------------------------------
#!/usr/bin/python
# Version 2

###############################################################################
#
#       Prerequisites to run this script:
#       ---------------------------------------
#               - Python 2.7 must be installed
#       Command Line Parameters to this script:
#
#       ---------------------------------------
#               $1 = GN Id of Ground Network
#               $2 = EMS Ip Address
#               $3 = Type of Component
#               $4 = Instance of Component
#               $5 = Desired state to be changed
#
#       Return values of the script:
#       ----------------------------
#               On successful execution, the exit status is 0
#
###############################################################################

##########################################
# --- Imported Basic Needful Modules --- #
##########################################

import os
import readline
import signal
import errno
import time
import logging
from datetime import datetime

#####################################
# --- Functioon to Handle Signal ---#
#####################################

def signal_handler(signal,frame):
        print('\n')
        print("Entering Signal Handler to Handle Recieved Signal")
        print('\n');print (" Successfully exited on User Request !! ")
        exit(0)

################################################
# --- Function to Create Directory for Log --- #
################################################

def create_log_dir():
        dir_log = 'state_logs'
        try:
           os.mkdir(dir_log)
           print("Logger Directory is Created")

        except OSError as e:
            if e.errno == errno.EEXIST:
                print("Log Directory already Exist - Not Creating Again")

######################################
# --- Function of START UP Menu ---  #
######################################

def start_menu():
	
	logger.info("Entering Start_menu")
	global comp,instance,state
        print("#####*****************************************#####")
        print("##### GN COMPONENT DESIRED STATE MODIFYER #####")
        print("#####*****************************************#####");print('\n')
	
	gn_id = raw_input("Enter the GN ID : ")
	ems_ip = raw_input("Enter the Ip Address of EMS (x.x.x.x.21 ) : ")
        comp = raw_input("Enter the Name of Component (ams,axp,debug,img,ldap,log,pls,rms,lxp) : ")
	instance = raw_input("Enter the Instance of Component ( xxx (For Eg : 001) ) : ")
	comp_state = raw_input("Enter the future Desired state (INSERVICE-1 / OUT_OF_SERVICE-2 / MAINTAINCE-3 ) : ")
	comp_name = ""+str(comp)+""+str(instance)+".snp.owgn0"+str(gn_id)+"";print('\n')
	print("Component Selected for State Change : ",comp_name);print('\n')
	time.sleep(2)
	state_modifyer(ems_ip,comp_name,comp_state)


#######################################
# --- Function of State Modifyer ---  #
#######################################

def state_modifyer(ems_ip,comp_name,comp_state):
	logger.info("Entering state_modifyer")
	cmd = "curl --insecure -X PUT -H 'Authorization: Bearer 5b87c735ebc11b9382fb9be3a09558486c44ad2f' -H 'Content-Type:application/json' https://"+str(ems_ip)+"/gnems/EMSAPI/v1/components/state/componentName/"+str(comp_name)+" -d '{\"state\":\""+str(comp_state)+"\"}'"

	os.system(cmd);print('\n')
	
######################################################
# --- Execution starts from Here - MAIN_FUNCTION --- #
######################################################

if __name__=="__main__":
	
	# Declaring Varibales  
 	comp = ''
	instance = ''
	comp_state = ''
	ems_ip=''
	comp_name=''
	gn_id=''

	signal.signal(signal.SIGINT,signal_handler)
        signal.signal(signal.SIGTSTP,signal_handler)

        os.system("clear")

        time.sleep(1)

        create_log_dir()

        #Basic Configuration for Generating Logs

        logFname = datetime.now().strftime('GN_COMP_STATE_%d_%m_%Y:%H_%M.log')
        logging.basicConfig(filename='state_logs/%s' %(logFname),level=logging.DEBUG,format='%(asctime)s : %(message)s ')
        logger = logging.getLogger()
        os.system("clear")

   	start_menu()	
